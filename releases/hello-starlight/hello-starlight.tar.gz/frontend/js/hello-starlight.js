/**
 * Hello Starlight - Test Addon Frontend
 * 
 * Demonstrates frontend integration with Starlight's addon system. 
 */

const HelloStarlight = {
    // Current counter value
    counter: 0,
    
    /**
     * Initialize the addon. 
     * Called automatically by Starlight when the addon is loaded. 
     */
    async init() {
        console.log('🌟 Hello Starlight addon initialized!');
        
        // Check if we're on the addon page
        if (this.isOnAddonPage()) {
            await this.setupPage();
        }
    },
    
    /**
     * Check if the current page is the Hello Starlight addon page.
     */
    isOnAddonPage() {
        return document.getElementById('hello-starlight-container') !== null;
    },
    
    /**
     * Set up the addon page with event listeners and initial data.
     */
    async setupPage() {
        console.log('🌟 Setting up Hello Starlight page...');
        
        // Bind button event listeners
        this.bindEvents();
        
        // Load initial data
        await this.loadInfo();
        await this.loadCounter();
        
        // Add a startup animation
        this.animateStartup();
    },
    
    /**
     * Bind click events to buttons. 
     */
    bindEvents() {
        const incrementBtn = document.getElementById('hs-increment-btn');
        const resetBtn = document. getElementById('hs-reset-btn');
        const refreshBtn = document.getElementById('hs-refresh-btn');
        
        if (incrementBtn) {
            incrementBtn. addEventListener('click', () => this.incrementCounter());
        }
        
        if (resetBtn) {
            resetBtn.addEventListener('click', () => this.resetCounter());
        }
        
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.loadInfo());
        }
    },
    
    /**
     * Load addon info from the backend.
     */
    async loadInfo() {
        try {
            const response = await fetch('/api/addon/hello-starlight/info');
            const result = await response.json();
            
            if (result.success) {
                this. renderInfo(result. data);
            } else {
                this.showError('Failed to load addon info');
            }
        } catch (error) {
            console.error('Error loading addon info:', error);
            this.showError('Error connecting to backend');
        }
    },
    
    /**
     * Load the current counter value. 
     */
    async loadCounter() {
        try {
            const response = await fetch('/api/addon/hello-starlight/counter');
            const result = await response. json();
            
            if (result. success) {
                this.counter = result.data. counter;
                this.updateCounterDisplay();
            }
        } catch (error) {
            console.error('Error loading counter:', error);
        }
    },
    
    /**
     * Increment the counter. 
     */
    async incrementCounter() {
        const btn = document.getElementById('hs-increment-btn');
        if (btn) btn.disabled = true;
        
        try {
            const response = await fetch('/api/addon/hello-starlight/counter', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            });
            const result = await response. json();
            
            if (result. success) {
                this.counter = result.data.counter;
                this.updateCounterDisplay();
                this.animateCounter();
                this.showMessage(result.data.message);
            }
        } catch (error) {
            console.error('Error incrementing counter:', error);
            this.showError('Failed to increment counter');
        } finally {
            if (btn) btn. disabled = false;
        }
    },
    
    /**
     * Reset the counter to zero. 
     */
    async resetCounter() {
        const btn = document.getElementById('hs-reset-btn');
        if (btn) btn.disabled = true;
        
        try {
            const response = await fetch('/api/addon/hello-starlight/reset', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            });
            const result = await response. json();
            
            if (result. success) {
                this.counter = result.data.counter;
                this.updateCounterDisplay();
                this.showMessage(result.data.message);
            }
        } catch (error) {
            console.error('Error resetting counter:', error);
            this.showError('Failed to reset counter');
        } finally {
            if (btn) btn.disabled = false;
        }
    },
    
    /**
     * Update the counter display element.
     */
    updateCounterDisplay() {
        const counterEl = document.getElementById('hs-counter-value');
        if (counterEl) {
            counterEl.textContent = this.counter;
        }
    },
    
    /**
     * Render addon info in the info panel.
     */
    renderInfo(data) {
        const infoContainer = document.getElementById('hs-info-content');
        if (! infoContainer) return;
        
        infoContainer.innerHTML = `
            <div class="hs-info-item">
                <span class="hs-info-label">Version:</span>
                <span class="hs-info-value">${data.version}</span>
            </div>
            <div class="hs-info-item">
                <span class="hs-info-label">Installed:</span>
                <span class="hs-info-value">${this.formatDate(data.state.installed_at)}</span>
            </div>
            <div class="hs-info-item">
                <span class="hs-info-label">Last Enabled:</span>
                <span class="hs-info-value">${this.formatDate(data.state.last_enabled)}</span>
            </div>
            <div class="hs-info-item">
                <span class="hs-info-label">Total Visits:</span>
                <span class="hs-info-value">${data.state.total_visits}</span>
            </div>
            <div class="hs-features">
                <h4>Features Tested:</h4>
                <ul>
                    ${data.features_tested.map(f => `<li>✓ ${f}</li>`).join('')}
                </ul>
            </div>
        `;
    },
    
    /**
     * Format a date string for display.
     */
    formatDate(dateStr) {
        if (!dateStr || dateStr === 'Unknown' || dateStr === 'Never') {
            return dateStr || 'Unknown';
        }
        try {
            const date = new Date(dateStr);
            return date.toLocaleString();
        } catch {
            return dateStr;
        }
    },
    
    /**
     * Show a success/info message.
     */
    showMessage(msg) {
        const msgEl = document.getElementById('hs-message');
        if (msgEl) {
            msgEl.textContent = msg;
            msgEl.className = 'hs-message hs-message-success';
            msgEl.style.display = 'block';
            
            setTimeout(() => {
                msgEl.style.display = 'none';
            }, 3000);
        }
    },
    
    /**
     * Show an error message.
     */
    showError(msg) {
        const msgEl = document.getElementById('hs-message');
        if (msgEl) {
            msgEl.textContent = msg;
            msgEl.className = 'hs-message hs-message-error';
            msgEl.style.display = 'block';
            
            setTimeout(() => {
                msgEl.style. display = 'none';
            }, 5000);
        }
    },
    
    /**
     * Animate the counter on increment.
     */
    animateCounter() {
        const counterEl = document.getElementById('hs-counter-value');
        if (counterEl) {
            counterEl.classList.add('hs-counter-bump');
            setTimeout(() => {
                counterEl.classList.remove('hs-counter-bump');
            }, 300);
        }
    },
    
    /**
     * Animate page startup. 
     */
    animateStartup() {
        const container = document.getElementById('hello-starlight-container');
        if (container) {
            container.classList.add('hs-fade-in');
        }
    }
};

// Export to window for Starlight to access
window.HelloStarlight = HelloStarlight;