/**
 * Hello Starlight - Test Addon Frontend
 * 
 * This module provides frontend functionality for testing the Starlight addon system.
 */

const HelloStarlight = {
    // Addon state
    initialized: false,
    status: null,

    /**
     * Initialize the addon
     * Called automatically by Starlight when the addon loads
     */
    async init() {
        console.log('[HelloStarlight] Initializing addon...');
        
        try {
            await this.fetchStatus();
            this.initialized = true;
            console.log('[HelloStarlight] Addon initialized successfully');
        } catch (error) {
            console.error('[HelloStarlight] Failed to initialize:', error);
        }
    },

    /**
     * Fetch current addon status from the backend
     */
    async fetchStatus() {
        try {
            const response = await fetch('/api/addon/hello-starlight/status');
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            this.status = await response.json();
            this.updateStatusDisplay();
            return this.status;
        } catch (error) {
            console. error('[HelloStarlight] Failed to fetch status:', error);
            throw error;
        }
    },

    /**
     * Test the ping endpoint
     */
    async testPing() {
        const resultEl = document.getElementById('hello-ping-result');
        if (resultEl) {
            resultEl.textContent = 'Pinging...';
            resultEl.className = 'hello-result pending';
        }

        try {
            const startTime = performance.now();
            const response = await fetch('/api/addon/hello-starlight/ping');
            const endTime = performance.now();
            
            if (! response.ok) {
                throw new Error(`HTTP ${response. status}`);
            }
            
            const data = await response.json();
            const latency = Math.round(endTime - startTime);
            
            if (resultEl) {
                resultEl.textContent = `✓ ${data.message} (${latency}ms)`;
                resultEl.className = 'hello-result success';
            }
            
            // Refresh status to update request count
            await this.fetchStatus();
            
            return data;
        } catch (error) {
            if (resultEl) {
                resultEl.textContent = `✗ Error: ${error.message}`;
                resultEl.className = 'hello-result error';
            }
            throw error;
        }
    },

    /**
     * Test the echo endpoint
     */
    async testEcho() {
        const inputEl = document.getElementById('hello-echo-input');
        const resultEl = document. getElementById('hello-echo-result');
        
        const message = inputEl?. value || 'Hello, Starlight!';
        
        if (resultEl) {
            resultEl. textContent = 'Sending... ';
            resultEl.className = 'hello-result pending';
        }

        try {
            const response = await fetch('/api/addon/hello-starlight/echo', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message: message, timestamp: new Date(). toISOString() })
            });
            
            if (! response.ok) {
                throw new Error(`HTTP ${response. status}`);
            }
            
            const data = await response.json();
            
            if (resultEl) {
                resultEl.textContent = `✓ Echo received: ${JSON.stringify(data. echo)}`;
                resultEl.className = 'hello-result success';
            }
            
            // Refresh status to update request count
            await this.fetchStatus();
            
            return data;
        } catch (error) {
            if (resultEl) {
                resultEl.textContent = `✗ Error: ${error. message}`;
                resultEl.className = 'hello-result error';
            }
            throw error;
        }
    },

    /**
     * Update the status display on the page
     */
    updateStatusDisplay() {
        if (!this.status) return;

        const statusEl = document.getElementById('hello-status');
        if (statusEl) {
            statusEl.innerHTML = `
                <div class="hello-status-item">
                    <span class="hello-status-label">Addon Version:</span>
                    <span class="hello-status-value">${this.status. version}</span>
                </div>
                <div class="hello-status-item">
                    <span class="hello-status-label">Server Time:</span>
                    <span class="hello-status-value">${this. status.server_time}</span>
                </div>
                <div class="hello-status-item">
                    <span class="hello-status-label">Installed At:</span>
                    <span class="hello-status-value">${this.status.status. installed_at || 'Unknown'}</span>
                </div>
                <div class="hello-status-item">
                    <span class="hello-status-label">Enabled At:</span>
                    <span class="hello-status-value">${this.status.status.enabled_at || 'Unknown'}</span>
                </div>
                <div class="hello-status-item">
                    <span class="hello-status-label">Request Count:</span>
                    <span class="hello-status-value">${this. status.status.request_count}</span>
                </div>
                <div class="hello-status-item">
                    <span class="hello-status-label">Last Ping:</span>
                    <span class="hello-status-value">${this.status.status.last_ping || 'Never'}</span>
                </div>
            `;
        }
    },

    /**
     * Refresh all data
     */
    async refresh() {
        const refreshBtn = document.getElementById('hello-refresh-btn');
        if (refreshBtn) {
            refreshBtn.disabled = true;
            refreshBtn.textContent = 'Refreshing...';
        }

        try {
            await this. fetchStatus();
        } finally {
            if (refreshBtn) {
                refreshBtn.disabled = false;
                refreshBtn.textContent = 'Refresh Status';
            }
        }
    }
};

// Export for Starlight to call
window.HelloStarlight = HelloStarlight;