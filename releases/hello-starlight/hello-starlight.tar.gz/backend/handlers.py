"""
Hello Starlight - Test Addon Backend Handlers

This module demonstrates all backend capabilities of the Starlight addon system.
"""

import datetime
from typing import Dict, Any


# ============================================================================
# Lifecycle Hooks
# ============================================================================

def on_install(context):
    """Called when the addon is first installed."""
    context.log_info("Hello Starlight addon installed!")
    
    # Initialize default data
    initial_data = {
        "counter": 0,
        "installed_at": datetime.datetime. now(). isoformat(),
        "visits": []
    }
    context.save_data("state. json", initial_data)


def on_uninstall(context):
    """Called before the addon is removed."""
    context. log_info("Hello Starlight addon uninstalled!")
    # Clean up any addon data if needed
    context.delete_data("state.json")


def on_enable(context):
    """Called when the addon is enabled."""
    context. log_info("Hello Starlight addon enabled!")
    
    # Load or initialize state
    state = context.load_data("state.json", default={"counter": 0, "visits": []})
    state["last_enabled"] = datetime.datetime.now().isoformat()
    context.save_data("state.json", state)


def on_disable(context):
    """Called when the addon is disabled."""
    context.log_info("Hello Starlight addon disabled!")
    
    state = context.load_data("state.json", default={})
    state["last_disabled"] = datetime.datetime.now().isoformat()
    context.save_data("state.json", state)


# ============================================================================
# API Route Handlers
# ============================================================================

def get_info(context) -> Dict[str, Any]:
    """
    GET /api/addon/hello-starlight/info
    
    Returns basic addon information and system status.
    """
    state = context.load_data("state.json", default={})
    
    return {
        "success": True,
        "data": {
            "addon_name": "Hello Starlight",
            "version": "1. 0.0",
            "description": "A test addon demonstrating Starlight addon capabilities",
            "features_tested": [
                "Sidebar integration",
                "Custom pages",
                "Backend API routes",
                "Lifecycle hooks",
                "Data persistence",
                "Frontend JavaScript",
                "Custom CSS styling"
            ],
            "state": {
                "installed_at": state.get("installed_at", "Unknown"),
                "last_enabled": state. get("last_enabled", "Never"),
                "total_visits": len(state.get("visits", []))
            }
        }
    }


def get_counter(context) -> Dict[str, Any]:
    """
    GET /api/addon/hello-starlight/counter
    
    Returns the current counter value. 
    """
    state = context.load_data("state.json", default={"counter": 0})
    
    return {
        "success": True,
        "data": {
            "counter": state.get("counter", 0)
        }
    }


def increment_counter(context) -> Dict[str, Any]:
    """
    POST /api/addon/hello-starlight/counter
    
    Increments the counter and returns the new value. 
    """
    state = context.load_data("state.json", default={"counter": 0, "visits": []})
    
    # Increment counter
    state["counter"] = state.get("counter", 0) + 1
    
    # Record the visit
    state["visits"].append({
        "timestamp": datetime.datetime.now(). isoformat(),
        "action": "increment"
    })
    
    # Keep only last 100 visits
    state["visits"] = state["visits"][-100:]
    
    context.save_data("state.json", state)
    context.log_info(f"Counter incremented to {state['counter']}")
    
    return {
        "success": True,
        "data": {
            "counter": state["counter"],
            "message": f"Counter is now {state['counter']}"
        }
    }


def reset_counter(context) -> Dict[str, Any]:
    """
    POST /api/addon/hello-starlight/reset
    
    Resets the counter to zero.
    """
    state = context. load_data("state.json", default={"counter": 0, "visits": []})
    
    old_value = state.get("counter", 0)
    state["counter"] = 0
    
    state["visits"].append({
        "timestamp": datetime.datetime.now().isoformat(),
        "action": "reset",
        "old_value": old_value
    })
    
    context.save_data("state. json", state)
    context.log_info(f"Counter reset from {old_value} to 0")
    
    return {
        "success": True,
        "data": {
            "counter": 0,
            "message": f"Counter reset from {old_value} to 0"
        }
    }