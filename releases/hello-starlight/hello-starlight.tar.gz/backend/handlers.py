"""
Hello Starlight - Test Addon Backend Handlers

This module provides backend handlers for testing the Starlight addon system. 
"""

import json
import os
from datetime import datetime

# Addon data directory (set by AddonContext)
DATA_DIR = None

def set_data_dir(path):
    """Set the addon data directory."""
    global DATA_DIR
    DATA_DIR = path

def _get_status_file():
    """Get path to the status file."""
    if DATA_DIR:
        return os. path.join(DATA_DIR, 'status.json')
    return None

def _load_status():
    """Load status from file."""
    status_file = _get_status_file()
    if status_file and os.path.exists(status_file):
        with open(status_file, 'r') as f:
            return json.load(f)
    return {
        'installed_at': None,
        'enabled_at': None,
        'request_count': 0,
        'last_ping': None
    }

def _save_status(status):
    """Save status to file."""
    status_file = _get_status_file()
    if status_file:
        os.makedirs(os.path.dirname(status_file), exist_ok=True)
        with open(status_file, 'w') as f:
            json. dump(status, f, indent=2)

# =============================================================================
# API Route Handlers
# =============================================================================

async def get_status(request):
    """
    GET /api/addon/hello-starlight/status
    
    Returns the current status of the addon including install time,
    request count, and other diagnostic information.
    """
    status = _load_status()
    status['request_count'] += 1
    _save_status(status)
    
    return {
        'success': True,
        'addon': 'hello-starlight',
        'version': '1.0.0',
        'status': status,
        'server_time': datetime. now().isoformat()
    }

async def ping(request):
    """
    GET /api/addon/hello-starlight/ping
    
    Simple ping endpoint to test basic API connectivity.
    """
    status = _load_status()
    status['last_ping'] = datetime.now().isoformat()
    status['request_count'] += 1
    _save_status(status)
    
    return {
        'success': True,
        'message': 'pong',
        'timestamp': datetime.now(). isoformat()
    }

async def echo(request):
    """
    POST /api/addon/hello-starlight/echo
    
    Echoes back the request body.  Useful for testing POST requests.
    """
    try:
        body = await request.json()
    except:
        body = {}
    
    status = _load_status()
    status['request_count'] += 1
    _save_status(status)
    
    return {
        'success': True,
        'echo': body,
        'timestamp': datetime. now().isoformat()
    }

# =============================================================================
# Lifecycle Hooks
# =============================================================================

def on_install(context):
    """
    Called when the addon is first installed. 
    
    Args:
        context: AddonContext with addon information and utilities
    """
    global DATA_DIR
    DATA_DIR = context. data_dir
    
    status = {
        'installed_at': datetime.now().isoformat(),
        'enabled_at': None,
        'request_count': 0,
        'last_ping': None
    }
    _save_status(status)
    
    print(f"[HelloStarlight] Addon installed successfully at {status['installed_at']}")
    return True

def on_uninstall(context):
    """
    Called when the addon is being uninstalled. 
    
    Args:
        context: AddonContext with addon information and utilities
    """
    print("[HelloStarlight] Addon uninstalled - goodbye!")
    return True

def on_enable(context):
    """
    Called when the addon is enabled. 
    
    Args:
        context: AddonContext with addon information and utilities
    """
    global DATA_DIR
    DATA_DIR = context. data_dir
    
    status = _load_status()
    status['enabled_at'] = datetime. now().isoformat()
    _save_status(status)
    
    print(f"[HelloStarlight] Addon enabled at {status['enabled_at']}")
    return True

def on_disable(context):
    """
    Called when the addon is disabled.
    
    Args:
        context: AddonContext with addon information and utilities
    """
    status = _load_status()
    status['enabled_at'] = None
    _save_status(status)
    
    print("[HelloStarlight] Addon disabled")
    return True

def on_upgrade(context, old_version, new_version):
    """
    Called when the addon is upgraded from one version to another. 
    
    Args:
        context: AddonContext with addon information and utilities
        old_version: Previous version string
        new_version: New version string
    """
    print(f"[HelloStarlight] Addon upgraded from {old_version} to {new_version}")
    return True